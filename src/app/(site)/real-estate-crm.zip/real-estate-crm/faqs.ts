
export const REAL_ESTATE_CRM_FAQS = [
  {
    question: "What is a real estate CRM?",
    answer:
      "A real estate CRM is software that helps agents, brokers and agencies manage leads, customers, property inventory, follow-ups and sales opportunities from one platform. Instead of spreading work across spreadsheets and chat threads, BROSAVO Real Estate CRM keeps the sales workflow in one place so your team can qualify enquiries, match listings and close deals with a clear next action.",
  },

  {
    question: "Who makes BROSAVO Real Estate CRM?",
    answer:
      "BROSAVO Real Estate CRM is developed by BROSAVO Technologies, a global technology company that builds websites, custom software, AI-powered applications and industry-specific business platforms. BROSAVO is not exclusively a real estate CRM company — Real Estate CRM is one product in the BROSAVO portfolio.",
  },

  {
    question: "What is the best CRM for real estate?",
    answer:
      "The best CRM for real estate depends on your team size, market and workflow. Most teams look for lead management, property inventory, property matching, a sales pipeline, WhatsApp integration, website lead capture and reporting in one platform. BROSAVO Real Estate CRM is built around that workflow for agents, brokers, agencies and developers evaluating real estate CRM software.",
  },

  {
    question: "How does BROSAVO help real estate agents?",
    answer:
      "BROSAVO Real Estate CRM helps agents capture website and WhatsApp enquiries, organize customer requirements, manage property inventory and move opportunities through a sales pipeline. Follow-ups, tasks and reporting sit next to each lead, so agents spend less time hunting for context and more time converting prospects into site visits and closed deals.",
  },

  {
    question: "What are the BROSAVO Real Estate CRM pricing options?",
    answer:
      "Starter is ₹999 per month for individual agents who need a website, CRM and lead management. Professional is ₹2,499 per month for teams that need collaboration, WhatsApp API, automation and analytics. Enterprise is custom-priced for multi-branch agencies and developers. Starter and Professional include a 14-day free trial with no long-term commitment to start.",
  },

  {
    question: "Does Brosavo support WhatsApp for real estate sales?",
    answer:
      "Yes. Starter includes WhatsApp notifications, and Professional adds WhatsApp API integration so conversations stay closer to the CRM record. Teams can follow up on property enquiries without losing ownership, history or the next pipeline step, which keeps lead management and messaging in one workflow.",
  },

  {
    question: "Does Brosavo include a real estate website?",
    answer:
      "Yes. Starter includes a professional website with property listings and lead capture. Professional adds blog, SEO tools and property portal capabilities so enquiries from your site flow into the same CRM used for inventory, follow-ups and sales reporting instead of landing in a disconnected inbox.",
  },

  {
    question: "Can Brosavo manage property inventory and sales pipelines?",
    answer:
      "Yes. Brosavo stores listings, availability, pricing and property details next to customer requirements. A structured sales pipeline shows which opportunities are new, qualified, in negotiation or closed, so managers can assign ownership, see stalled deals and keep property management aligned with selling activity.",
  },

  {
    question: "Does Brosavo offer a free trial?",
    answer:
      "Yes. Starter and Professional include a 14-day free trial so your team can evaluate lead management, property inventory, follow-ups and reporting before choosing a paid plan. You can explore the CRM for agents workflow without a long-term commitment during the trial period.",
  },

  {
    question: "Is Brosavo suitable for agencies and property developers?",
    answer:
      "Yes. Individual agents can start on Starter, while brokerages, agencies and developers can use Professional or Enterprise. Enterprise supports multiple users, websites and branches, custom integrations, API access, advanced permissions and data migration for larger real estate operations.",
  },

  {
    question: "Can Brosavo take 99acres and MagicBricks leads?",
    answer:
      "Portal enquiries can sit in Brosavo when your 99acres or MagicBricks account supports a lead-delivery method the CRM can use, including approved integrations, email-based intake, or CSV import. See the 99acres and MagicBricks sync guide for the intake options.",
  },

  {
    question: "Can I import my existing leads into Brosavo?",
    answer:
      "Yes. Brosavo can support importing existing lead data so your team can move customer records into the CRM instead of starting from scratch. Depending on your data source and format, lead information can be prepared for import and organized within Brosavo for follow-ups, assignment and sales pipeline management.",
  },

  {
    question: "Can multiple salespeople use Brosavo?",
    answer:
      "Yes. Brosavo is designed for real estate teams as well as individual agents. Multiple salespeople can work within the CRM, manage assigned leads, update opportunities and collaborate on follow-ups. Professional and Enterprise plans provide additional team and collaboration capabilities for growing agencies.",
  },

  {
    question: "Can I connect WhatsApp to Brosavo?",
    answer:
      "Yes. Brosavo supports WhatsApp capabilities for real estate sales. Starter includes WhatsApp notifications, while Professional includes WhatsApp API integration. This helps teams keep customer communication connected to their lead management workflow and follow up on enquiries more efficiently.",
  },

  {
    question: "Can I capture leads from my website with Brosavo?",
    answer:
      "Yes. Brosavo can capture enquiries generated through your real estate website and bring them into the CRM workflow. This allows website enquiries to be organized alongside customer requirements, property interests, follow-ups and sales opportunities instead of being managed separately.",
  },

  {
    question: "Can I manage property inventory in Brosavo?",
    answer:
      "Yes. Brosavo includes property inventory management for organizing listings and their key details. Teams can maintain property information alongside customer requirements and sales opportunities, making it easier to keep available inventory connected to the sales process.",
  },

  {
    question: "Can Brosavo match properties to leads?",
    answer:
      "Yes. Brosavo is designed to connect customer requirements with relevant property inventory. Agents can use lead requirements such as property type, location, budget and other preferences to identify suitable listings and move qualified opportunities into the sales workflow.",
  },

  {
    question: "Does Brosavo have a mobile CRM?",
    answer:
      "Yes. Brosavo is designed to support real estate teams that need access to CRM workflows while working away from the office. Mobile CRM capabilities help agents stay connected with leads, customer information, follow-ups and sales activity while they are meeting prospects or visiting properties.",
  },

  {
    question: "Can I track follow-ups in Brosavo?",
    answer:
      "Yes. Brosavo helps agents organize and track follow-up activity against leads and sales opportunities. Teams can keep track of the next action, customer conversations and pipeline progress so important property enquiries are less likely to be forgotten.",
  },

  {
    question: "What happens after the Brosavo free trial?",
    answer:
      "After the 14-day free trial, you can choose the Brosavo plan that best fits your requirements. You can continue with a paid Starter or Professional plan, or contact Brosavo if your organization needs an Enterprise setup. The trial gives your team an opportunity to evaluate the CRM before making that decision.",
  },

  {
    question: "Can I upgrade my Brosavo plan later?",
    answer:
      "Yes. You can move to a higher Brosavo plan as your real estate business grows and your requirements change. For example, an individual agent can start with Starter and move to Professional when they need additional team collaboration, WhatsApp API integration, automation and advanced analytics.",
  },
] as const;